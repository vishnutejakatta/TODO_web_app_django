from django.db import models
from django.utils import timezone
# Create your models here.


class TodoTable(models.Model):
    content = models.TextField()
    color = models.TextField(default='Hey')
    date_created = models.DateTimeField(default=timezone.now)
