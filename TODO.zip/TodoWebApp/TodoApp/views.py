from django.shortcuts import render
from django.http import HttpResponseRedirect
from .models import TodoTable
from django.utils import timezone

# Create your views here.

bootstrap_colors = [
        'list-group-item-primary',
        'list-group-item-secondary',
        'list-group-item-success',
        'list-group-item-danger',
        'list-group-item-warning',
        'list-group-item-info',
        'list-group-item-light',
        'list-group-item-dark',
    ]


def index(request):
    items = TodoTable.objects.all()
    cnt = items.count()
    i = 0
    if cnt > 0:
        context = {"todo_items": items.order_by('-date_created'), 'count': cnt}
    else:
        context = {"todo_items": items.order_by('-date_created')}
    return render(request, 'TodoApp/todo.html', context)


def add_item(request):
    if request.method == 'POST':
        content = request.POST['content']
        item = TodoTable(content=content, date_created=timezone.now())
        item.save()
        item.color = bootstrap_colors[item.id % 8]
        item.save()
        return HttpResponseRedirect('/todoPage/')


def delete_item(request, id):
    item = TodoTable.objects.get(id=id)
    item.delete()
    return HttpResponseRedirect('/todoPage/')
